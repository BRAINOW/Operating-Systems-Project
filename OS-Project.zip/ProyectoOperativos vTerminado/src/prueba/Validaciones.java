package prueba;
import javax.swing.JOptionPane;

public class Validaciones {

    public static int validarEntero(String mensaje) {
        int numero = 0;
        boolean esEntero = false;

        while (!esEntero) {
            try {
                String input = JOptionPane.showInputDialog(mensaje);
                if (input != null) {//mientras no sea nulo
                    numero = Integer.parseInt(input);//convierte a entero
                    if (numero > 0 && numero >=200) {//checa que no sea negativo y sea mayor de 200
                        esEntero = true;
                    } else {//si es negativo
                        JOptionPane.showMessageDialog(null, "Error: Por favor, ingresa un número entero no negativo o mayor a 200.");
                    }
                } else {// si no se ingreso nada
                    JOptionPane.showMessageDialog(null, "Operación cancelada.");// se cancela
                    System.exit(0); // El argumento 0 indica una terminación exitosa
                }
            } catch (NumberFormatException e) {//
                JOptionPane.showMessageDialog(null, "Error: Por favor, ingresa un número entero válido.");
            }
        }
        return numero;
    }



    public static int validarPotenciaDeDos(String mensaje) {
        int numero = 0;
        boolean esNumeroValido = false;

        while (!esNumeroValido) {
            try {
                String input = JOptionPane.showInputDialog(mensaje);//muestra el texto que se recibio
                if (input != null) {//mientras no sea nulo
                    numero = Integer.parseInt(input);//convierte a entero
                    if (numero >= 1 && numero <= 8) {//verifica rango
                        esNumeroValido = true;
                    } else {//marca error en caso de que no
                        JOptionPane.showMessageDialog(null, "Error: Por favor, ingresa un número entre 1 y 8.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Operación cancelada.");// se cancela
                    System.exit(0); // El argumento 0 indica una terminación exitosa
                    //return -1; // Devuelve -1 para indicar que la operación fue cancelada
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Por favor, ingresa un número válido.");
            }
        }
        return numero;
    }

    public static String validarLetras(String mensaje) {
        String entrada = "";//vacio
        while (true) {
            entrada = JOptionPane.showInputDialog(mensaje);//saca el valor del JOption
            if (esString(entrada)) {//checa si concide entre las letras
                break;//sale del bucle
            } else {//no hay letras
                JOptionPane.showMessageDialog(null, "Error: Por favor, ingresa una cadena de texto válida con solo letras.");
            }
        }

        return entrada;
    }

    public static boolean esString(String entrada) {//checa si concide entre las letras
        return entrada.matches("[a-zA-Z]+");
    }
}
