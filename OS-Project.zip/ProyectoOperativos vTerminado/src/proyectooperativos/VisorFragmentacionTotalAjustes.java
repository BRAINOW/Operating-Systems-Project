/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectooperativos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;

/**
 *
 * @author brian
 */
public class VisorFragmentacionTotalAjustes extends javax.swing.JFrame {
    int xMouse,yMouse;//UBICACION MOUSE
    public VisorFragmentacionTotalAjustes() {
        initComponents();
        setIconImage(getIconImage());
        lbTamAjustes.setText("Tamaño Ajustes: "+Sinc.tamanyoAjustes+ " kilobyte ");
        flechaProx.setBounds(760+Sinc.recorridoPuntero-8, flechaProx.getBounds().y, 20, 30);
        lblLeyenda.setText(Sinc.calculaLeyenda());
    }
    
    @Override
    public Image getIconImage(){
        Image retValue=Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("\\img\\ram.png"));
        return retValue;
    }
    boolean bandera = false;
    
    public void start(){
        
        //Genera el grafico para el ajuste con los datos de todos los ajustes
        JFreeChart graficoAjustes = ChartFactory.createBarChart3D(
                "Fragmentación total de los ajustes",
                "Bloque de memoria",
                "% de fragmentación total",
                Sinc.datos,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );
        
        //Genera la imagen de panel de la grafica
        ChartPanel chartPanelAjustes = new ChartPanel(graficoAjustes);
        chartPanelAjustes.setMouseWheelEnabled(true);
        chartPanelAjustes.setPreferredSize(new Dimension(1100,470));
        
        //Mostramos el panel
        panelAjustes.setLayout(new BorderLayout());
        panelAjustes.add(chartPanelAjustes,BorderLayout.NORTH);
        
        lblPrimer.setText("Fragmentación primer ajuste = "+Sinc.fragTotalPrimerA+"%");
        lblMejor.setText("Fragmentación mejor ajuste = "+Sinc.fragTotalMejorA+"%");
        lblProximo.setText("Fragmentación proximo ajuste = "+Sinc.fragTotalProximoA+"%");
          
//        pack();
    }
    
    
    public void actualizaTabla(){
        
        DefaultTableModel dtm;
        //Crea un objeto para la fila de la tabla
        Object[] fila = new Object[5];
        
        //Obtiene el modelo de la tabla
        dtm = (DefaultTableModel) tablaHistorial.getModel();
        dtm.getDataVector().removeAllElements(); //Limpia la tabla
        dtm.fireTableDataChanged();
        
        //Recorre los registros de la tabla
        for (int i = 0; i < Sinc.LTabla.size(); i++) {
            //Llena el objeto fila con lo corespondiente al registro
            fila[0] = Sinc.LTabla.get(i).nombre;
            if(compLiberarProceso(fila[0].toString())){ //Flujo normal
                fila[1] = Sinc.LTabla.get(i).tamanyo;

                switch(Sinc.LTabla.get(i).resultadoPimerA){
                    case 0: //Bloqueado
                        fila[2] = "Bloqueado";
                        break;
                    case 1: //Ingreso
                        fila[2] = "Ingresado";
                        break;
                    case 2: //Inanicion
                        fila[2] = "Inanición";
                        break;
                }
                switch(Sinc.LTabla.get(i).resultadoMejorA){
                    case 0: //Bloqueado
                        fila[3] = "Bloqueado";
                        break;
                    case 1: //Ingreso
                        fila[3] = "Ingresado";
                        break;
                    case 2: //Inanicion
                        fila[3] = "Inanición";
                        break;
                }
                switch(Sinc.LTabla.get(i).resultadoProximoA){
                    case 0: //Bloqueado
                        fila[4] = "Bloqueado";
                        break;
                    case 1: //Ingreso
                        fila[4] = "Ingresado";
                        break;
                    case 2: //Inanicion
                        fila[4] = "Inanición";
                        break;
                }
                dtm.addRow(fila);
            }
        }
        
    }
    
    public boolean compLiberarProceso(String proceso){
        //retorna true si el proceso ya salio
        for (int i = 0; i < Sinc.LTabla.size(); i++) {
            if("Salida".equals(Sinc.LTabla.get(i).tipoES) && Sinc.LTabla.get(i).nombre.equals(proceso)){
                return false;
            }
        }
        return true;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblLeyenda = new javax.swing.JLabel();
        panelInicial = new javax.swing.JPanel();
        panelPrimer = new javax.swing.JPanel();
        panelMejor = new javax.swing.JPanel();
        panelProximo = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        lblProximo = new javax.swing.JLabel();
        lblPrimer = new javax.swing.JLabel();
        lblMejor = new javax.swing.JLabel();
        flechaProx = new javax.swing.JLabel();
        panelAjustes = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaHistorial = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        lbTamAjustes = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btnExit = new javax.swing.JButton();
        btnStart = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblLeyenda.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblLeyenda.setText("Ajuste mas eficiente: - Sistema Buddy:");
        getContentPane().add(lblLeyenda, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 670, 640, 30));

        panelInicial.setBackground(new java.awt.Color(255, 255, 255));
        panelInicial.setPreferredSize(new java.awt.Dimension(700, 60));

        javax.swing.GroupLayout panelInicialLayout = new javax.swing.GroupLayout(panelInicial);
        panelInicial.setLayout(panelInicialLayout);
        panelInicialLayout.setHorizontalGroup(
            panelInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 700, Short.MAX_VALUE)
        );
        panelInicialLayout.setVerticalGroup(
            panelInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        getContentPane().add(panelInicial, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 530, -1, 40));

        panelPrimer.setBackground(new java.awt.Color(255, 255, 255));
        panelPrimer.setPreferredSize(new java.awt.Dimension(700, 60));

        javax.swing.GroupLayout panelPrimerLayout = new javax.swing.GroupLayout(panelPrimer);
        panelPrimer.setLayout(panelPrimerLayout);
        panelPrimerLayout.setHorizontalGroup(
            panelPrimerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 700, Short.MAX_VALUE)
        );
        panelPrimerLayout.setVerticalGroup(
            panelPrimerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        getContentPane().add(panelPrimer, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 626, -1, 40));

        panelMejor.setBackground(new java.awt.Color(255, 255, 255));
        panelMejor.setPreferredSize(new java.awt.Dimension(700, 60));

        javax.swing.GroupLayout panelMejorLayout = new javax.swing.GroupLayout(panelMejor);
        panelMejor.setLayout(panelMejorLayout);
        panelMejorLayout.setHorizontalGroup(
            panelMejorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 700, Short.MAX_VALUE)
        );
        panelMejorLayout.setVerticalGroup(
            panelMejorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        getContentPane().add(panelMejor, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 530, -1, 40));

        panelProximo.setBackground(new java.awt.Color(255, 255, 255));
        panelProximo.setPreferredSize(new java.awt.Dimension(700, 60));

        javax.swing.GroupLayout panelProximoLayout = new javax.swing.GroupLayout(panelProximo);
        panelProximo.setLayout(panelProximoLayout);
        panelProximoLayout.setHorizontalGroup(
            panelProximoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 700, Short.MAX_VALUE)
        );
        panelProximoLayout.setVerticalGroup(
            panelProximoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        getContentPane().add(panelProximo, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 626, -1, 40));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 193, 131));
        jLabel5.setText("Estado inicial de memoria");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 500, -1, -1));

        lblProximo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblProximo.setText("Proximo ajuste");
        getContentPane().add(lblProximo, new org.netbeans.lib.awtextra.AbsoluteConstraints(766, 600, -1, -1));

        lblPrimer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblPrimer.setText("Primer ajuste");
        getContentPane().add(lblPrimer, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 600, -1, -1));

        lblMejor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblMejor.setText("Mejor ajuste");
        getContentPane().add(lblMejor, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 510, -1, -1));

        flechaProx.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/flecha_v.png"))); // NOI18N
        getContentPane().add(flechaProx, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 672, 20, 30));

        panelAjustes.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout panelAjustesLayout = new javax.swing.GroupLayout(panelAjustes);
        panelAjustes.setLayout(panelAjustesLayout);
        panelAjustesLayout.setHorizontalGroup(
            panelAjustesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1100, Short.MAX_VALUE)
        );
        panelAjustesLayout.setVerticalGroup(
            panelAjustesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 470, Short.MAX_VALUE)
        );

        getContentPane().add(panelAjustes, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 20, -1, -1));

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(394, 6, -1, 0));

        tablaHistorial.setAutoCreateRowSorter(true);
        tablaHistorial.setBackground(new java.awt.Color(194, 210, 178));
        tablaHistorial.setForeground(new java.awt.Color(0, 0, 0));
        tablaHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Proceso", "Tamaño", "Primer", "Mejor", "Proximo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaHistorial.setToolTipText("");
        tablaHistorial.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane1.setViewportView(tablaHistorial);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 280, 380));

        jLabel4.setFont(new java.awt.Font("Segoe UI Variable", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 193, 131));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Historial de procesos");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 63, 280, -1));

        lbTamAjustes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbTamAjustes.setText("Tamaño Ajustes: ");
        getContentPane().add(lbTamAjustes, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 280, 31));

        jPanel1.setBackground(new java.awt.Color(153, 193, 131));
        jPanel1.setToolTipText("");
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        btnExit.setBackground(new java.awt.Color(153, 193, 131));
        btnExit.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnExit.setForeground(new java.awt.Color(0, 0, 0));
        btnExit.setText("X");
        btnExit.setBorder(null);
        btnExit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnExit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnExitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnExitMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnExitMousePressed(evt);
            }
        });
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        btnStart.setBackground(new java.awt.Color(153, 193, 131));
        btnStart.setForeground(new java.awt.Color(219, 201, 223));
        btnStart.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/play.png"))); // NOI18N
        btnStart.setToolTipText("START");
        btnStart.setBorder(null);
        btnStart.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnStart.setName("START"); // NOI18N
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        btnRegresar.setBackground(new java.awt.Color(153, 193, 131));
        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/deshacer.png"))); // NOI18N
        btnRegresar.setToolTipText("Regresar");
        btnRegresar.setBorder(null);
        btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1220, Short.MAX_VALUE)
                .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnRegresar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnStart, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnExit, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1500, 20));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoBlanco.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel1MouseEntered(evt);
            }
        });
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 1500, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        start();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        starter();
        actualizaPuntero();
    }//GEN-LAST:event_btnStartActionPerformed

    public void starter(){
        start();
        //Funcion que llama para actualizar el dibujo de la memoria
        Sinc.dibujaLista(Sinc.LInicial, panelInicial.getGraphics(),-1);
        Sinc.dibujaLista(Sinc.LPrimer, panelPrimer.getGraphics(),Sinc.posScannerPrimer);
        Sinc.dibujaLista(Sinc.LMejor, panelMejor.getGraphics(),Sinc.posScannerMejor);
        Sinc.dibujaLista(Sinc.LProximo, panelProximo.getGraphics(),Sinc.posScannerProximo);
        if(!bandera){
            bandera = true;
            starter();
        }
        
        //Se actualizan los datos de la tabla
       actualizaTabla();
    }
    
    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        //Regresa a pantalla principal
        Sinc.pantallaPrincipal.setVisible(true);
        Sinc.pantallaPrincipal.setSize(1300, 650);
        Sinc.pantallaPrincipal.setResizable(false);
        Sinc.pantallaPrincipal.setLocationRelativeTo(null);//en medio
        this.dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnExitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMouseEntered
        //listo
        btnExit.setBackground(Color.red);
    }//GEN-LAST:event_btnExitMouseEntered

    private void btnExitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMouseExited
        //listo
        btnExit.setBackground(new Color(153,193,131));
    }//GEN-LAST:event_btnExitMouseExited

    private void btnExitMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMousePressed
        //listo
        System.exit(0);
    }//GEN-LAST:event_btnExitMousePressed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        //NO SE OCUPA
    }//GEN-LAST:event_btnExitActionPerformed

    private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
        int x = evt.getXOnScreen();
        int y =evt.getYOnScreen();
        this.setLocation(x-xMouse,y-yMouse);
    }//GEN-LAST:event_jPanel1MouseDragged

    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_jPanel1MousePressed

    private void jLabel1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseEntered
        btnStartActionPerformed(null);
    }//GEN-LAST:event_jLabel1MouseEntered

    public void actualizaPuntero(){
        flechaProx.setBounds(760+Sinc.recorridoPuntero-8, flechaProx.getBounds().y, 20, 30);
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnStart;
    public static javax.swing.JLabel flechaProx;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbTamAjustes;
    private javax.swing.JLabel lblLeyenda;
    private javax.swing.JLabel lblMejor;
    private javax.swing.JLabel lblPrimer;
    private javax.swing.JLabel lblProximo;
    private javax.swing.JPanel panelAjustes;
    private javax.swing.JPanel panelInicial;
    private javax.swing.JPanel panelMejor;
    private javax.swing.JPanel panelPrimer;
    private javax.swing.JPanel panelProximo;
    private javax.swing.JTable tablaHistorial;
    // End of variables declaration//GEN-END:variables
}
