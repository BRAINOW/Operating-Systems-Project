/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectooperativos;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.ArrayList;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author brian
 */
public class Sinc {
    //Listas de control de memoria 
    static ArrayList <Espacio> LInicial = new ArrayList<>();
    static ArrayList <Espacio> LPrimer = new ArrayList<>();
    static ArrayList <Espacio> LMejor = new ArrayList<>();
    static ArrayList <Espacio> LProximo = new ArrayList<>();
    static ArrayList <Espacio> LBuddy = new ArrayList<>();
    static ArrayList <Registro> LTabla = new ArrayList<>();
    
    //Variables auxiliares globales
    static int cuentaHermanos = 0; //Contador para seguimiento de los hultimos hermanos generados por el buddy
    static int tamanyoBuddy; // Numero de Mb iniciales
    static int tamanyoAjustes; //Tamaño total del ajuste
    static int espacios; //Cantidad de bloques de memoria en los ajustes
    static int cuentaNombre = 0; //Contador que lleva el registro de nombre de los procesos generados
    static int recorridoPuntero = 0;
    static int limiteSuperior = 0;
    
    //Almacena la ubicacion del scanner en tiempo real
    static int posScannerPrimer = 0;
    static int posScannerMejor = 0;
    static int posScannerProximo = 0;
    
    
    //Datos para las graficas de barras
    static DefaultCategoryDataset datos = new DefaultCategoryDataset();
    static DefaultCategoryDataset datosFragmentacionBuddy = new DefaultCategoryDataset();
    
    //Datos para las graficas de pastel
    static DefaultPieDataset porcentajeBuddy = new DefaultPieDataset();
    static DefaultPieDataset porcentajePrimerAjuste= new DefaultPieDataset();
    static DefaultPieDataset porcentajeMejorAjuste = new DefaultPieDataset();
    static DefaultPieDataset porcentajeProximoAjuste = new DefaultPieDataset();
    
    //Porcentajes de fragmentación total
    static float fragTotalPrimerA;
    static float fragTotalMejorA;
    static float fragTotalProximoA;
    static float fragTotalSistemaBuddy;
    
    //Pantallas
    static Portada portada;
    static PantallaPrincipal pantallaPrincipal;
    static VisorFragmentacionTotalAjustes VisorFragmentacionTotal;
    static VisorFragmentacionTotalPasteles VisorFragmentacionTotalPasteles;
    static VisorFragmentacionTotalBuddy VisorFragmentacionTotalBuddy;
    static VisorFragmentacionTotalPorAjuste VisorFragmentacionTotalPorAjuste;
    
    public static void dibujaLista (ArrayList <Espacio> LAjuste, Graphics papel, int pos){
        //Tam lienzo [700, 60]
        int x = 5;
        int y = 5;
        int width = 0;
        
        //Se pinta el controrno de la memoria de verde si es que logro entrar y de rojo si es que no lo hizo
        switch(compruebaUltimaEntrada(LAjuste,papel)){
            case 0: //Bloqueado
                papel.setColor(Color.red);
                break;
            case 1: //Ingreso
                papel.setColor(Color.green);
                break;
            case 2: //Inanicion
                papel.setColor(Color.orange);
                break;
        }
        
        papel.fillRect(0, 0, 700, 40);
        
        papel.setColor(Color.white);
        papel.fillRect(5, 5, 690, 30);
        Font font = new Font("Arial",Font.BOLD,10);
        papel.setFont(font);
        
        for (int i = 0; i < LAjuste.size(); i++) {
            //En caso de ser el buddy se hace regla de 3 con 1024 kb
            if(LAjuste.containsAll(Sinc.LBuddy)){
                //En caso de que sea el sistema buddy
                width = (int)(((float)694*(float)LAjuste.get(i).tamanyo)/(float)(Sinc.tamanyoBuddy*1024)); //Regla de 3
            }else{
                //En caso de ser ajuste
                width = (int)(((float)694*(float)LAjuste.get(i).tamanyo)/(float)Sinc.tamanyoAjustes); //Regla de 3
                
                //Si el bloque actual es el mismo del scanner agrega marco magenta
                if(pos!=-1 && i==pos ){
                    papel.setColor(new Color(0, 0, 0));//puede ser negro tambien jaja
                    papel.fillRect(x-5, 0, width+10, 40);
                }
            }
            
            //Pinta el cuadro correspondiente al tipo de espacio 
            if (LAjuste.get(i).tipo == 0) { //Ocupadisimo
                papel.setColor(Color.gray);
                if(pos!=-1 && i==pos+1){
                    papel.fillRect(x+5, y, width-5, 30);
                }else{
                    papel.fillRect(x, y, width, 30);
                }
                papel.setColor(Color.white);
                papel.drawString(Integer.toString(LAjuste.get(i).tamanyo), x-5+width/2, y+20);
            }
            if (LAjuste.get(i).tipo == 1) { //Libre
                papel.setColor(Color.LIGHT_GRAY);
                
                if(pos!=-1 && i==pos+1){
                    papel.drawRect(x+5, y, width-5, 30);
                }else{
                    papel.drawRect(x, y, width, 30);
                }
                papel.drawString(Integer.toString(LAjuste.get(i).tamanyo), x-5+width/2, y+20);
            }
            if (LAjuste.get(i).tipo == 2) { //Ocupado
                papel.setColor(new Color(LAjuste.get(i).color[0], LAjuste.get(i).color[1], LAjuste.get(i).color[2]));
                if(pos!=-1 && i==pos+1){
                    papel.fillRect(x+5, y, width-5, 30);
                }else{
                    papel.fillRect(x, y, width, 30);
                }
                
                papel.setColor(Color.black);
                papel.drawString(LAjuste.get(i).nombre, x-5+width/2, y+20);
            }
            
            x+=width;
        }
    }
    
    public static int compruebaUltimaEntrada(ArrayList <Espacio> LAjuste, Graphics papel){
        //Comprueba si es que el proceso entro o no
        boolean bandera = true;
        //Recorre la lista completa de la tabla
        for (int i = 0; i < Sinc.LTabla.size(); i++) {
            bandera = true; //reiniciamos bandera
            
            //En caso de encontrar una entrada
            if(Sinc.LTabla.get(i).tipoES == "Entrada"){
                //Comprobamos que ese registro no haya salido ya
                for (int j = 0; j < Sinc.LTabla.size(); j++) {
                    //En caso de haber salido cambiamos bandera a false
                    if(Sinc.LTabla.get(i).nombre == Sinc.LTabla.get(j).nombre && Sinc.LTabla.get(j).tipoES == "Salida"){
                        bandera = false;
                    }
                }
                //retornamos si es que el ultimo proceso entro exitosamente o no
                if(bandera){
                    if(Sinc.LInicial.containsAll(LAjuste)){
                        return 1;
                    }
                    if(Sinc.LPrimer.containsAll(LAjuste)){
                        return Sinc.LTabla.get(i).resultadoPimerA;
                    }
                    if(Sinc.LMejor.containsAll(LAjuste)){
                        return Sinc.LTabla.get(i).resultadoMejorA;
                    }
                    if(Sinc.LProximo.containsAll(LAjuste)){
                        return Sinc.LTabla.get(i).resultadoProximoA;
                    }
                    if(Sinc.LBuddy.containsAll(LAjuste)){
                        return Sinc.LTabla.get(i).resultadoBuddy;
                    }
                }
            }
        }
        return 0;
    }
    
    public static String calculaLeyenda(){
        //Funcion que analiza cual de los ajustes es mas eficiente demas del sistema buddy
        String leyenda = "";
        String nombre = "Primer Ajuste";
        
        //Se asume que el primer ajuste es el mas eficiente al comienzo
        float ajusteEficiente = fragTotalPrimerA;
        
        //Se compara con el mejor ajuste
        if(fragTotalMejorA < ajusteEficiente){
            ajusteEficiente = fragTotalMejorA;
            nombre = "Mejor Ajuste";
        }
        
        //Se compara con el proximo ajuste
        if(fragTotalProximoA < ajusteEficiente){
            ajusteEficiente = fragTotalProximoA;
            nombre = "Proximo Ajuste";
        }
        
        //Se compone la leyenda 
        leyenda = "Ajuste mas eficiente es \""+ nombre +"\": "+ajusteEficiente+"% - Sistema Buddy: "+ fragTotalSistemaBuddy+"%";
        
        return leyenda;
    }
    
    //Funcion que realiza un retraso en el sistema
    public static void esperar(double segundos) {
        try {
            Thread.sleep ((int)(segundos*1000));
        } catch (Exception e) {
            // Mensaje en caso de que falle
            System.out.println("Algo ha salido mal (1)");
        }
    }
}
