package proyectooperativos;

public class ProyectoOperativos {

    public static void main(String[] args) {
        Sinc.portada = new Portada();
        Sinc.portada.setVisible(true);
        Sinc.portada.setSize(1150, 650);
        Sinc.portada.setResizable(false);
        Sinc.portada.setLocationRelativeTo(null);//en medio
    }
}
