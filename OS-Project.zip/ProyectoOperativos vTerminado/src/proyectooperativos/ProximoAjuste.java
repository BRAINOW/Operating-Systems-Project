/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectooperativos;

import java.awt.Graphics;

/**
 *
 * @author brian
 */
public class ProximoAjuste {
    static int posicion = 0; //variable estatica
    
    public int ingresaProceso(Espacio newEspacio, Graphics panel){
        //Aqui se debe agregar el nuevo espacio en la lista de "Sinc" correspondiente
        //Retorna true en caso de que si lo pueda insertar, de lo contrario false
        int bandera=0;
        
        if(newEspacio.tamanyo>Sinc.limiteSuperior){
            return 2;
        }
        
        for (; posicion < Sinc.LProximo.size(); posicion++) {//recorre la lista
            //Actualiza la lista para mostrar la posicion del scanner
            Sinc.dibujaLista(Sinc.LProximo, panel, posicion);
            Sinc.posScannerProximo = posicion; //Actualiza la ultima posicion del scanner
            Sinc.esperar(0.18);
            
            if(Sinc.LProximo.get(posicion).tipo == 1 ){// si hay un espacio vacio
                if(Sinc.LProximo.get(posicion).tamanyo>=newEspacio.tamanyo){//checa si el newEspacio cabe en ese i espacio
                    //restamos el espacio en donde si entra, pero si es igual no lo hago? B: Yo digo que no solo cambiale los parametros
                    if(Sinc.LProximo.get(posicion).tamanyo!=newEspacio.tamanyo){//ES DIFERENTE EL ESPACIO
                        Sinc.LProximo.get(posicion).tamanyo=Sinc.LProximo.get(posicion).tamanyo-newEspacio.tamanyo;
                        //agrega espacio antes uno nuevo con el tamanio del nuevo
//                        newEspacio.tipo=2;
                        newEspacio.nBloqueInicial = Sinc.LProximo.get(posicion).nBloqueInicial;
                        Sinc.LProximo.add(posicion,newEspacio);
                    }else{// ES EL MISMO ESPACIO
                        //le ponemos todos los datos del nuevo a ese espacio vacio
                        Sinc.LProximo.get(posicion).nombre = newEspacio.nombre;
                        Sinc.LProximo.get(posicion).tipo = 2;//ahora es ocupado pero que se puede liberar
                        Sinc.LProximo.get(posicion).color[0] = newEspacio.color[0];
                        Sinc.LProximo.get(posicion).color[1] = newEspacio.color[1];
                        Sinc.LProximo.get(posicion).color[2] = newEspacio.color[2];
                    }
                    bandera= 1; //Revisar
                    break;
                }else{//es el ultimo y no cupo en algun espacio
                    bandera= 0;
                }
            }
        }
        
        //En caso de que se acabe el espacio el puntero se reinicia
        if(!(posicion < Sinc.LProximo.size())){
            posicion = 0;
            Sinc.posScannerProximo = -1; //Actualiza la ultima posicion para que nos e muestre en caso de no entrar
        }
        
        actualizaPuntero();
        return bandera;
    }
    
    public static void actualizaPuntero(){
        int sumaTamanyos = 0;
        
        int x = 540;
        int y = 420;
        
        //Calcula el espacio recorrido hasta la posicion
        for (int i = 0; i < posicion; i++) {
            try{
                sumaTamanyos += Sinc.LProximo.get(i).tamanyo;
            }catch(Exception e){}
        }
        
        if(posicion!=0){
            //Calcula el equivalente al desplazamiento en x de la memoria con respecto al tamaño del lienzo
            try{
                Sinc.recorridoPuntero = ((sumaTamanyos + Sinc.LProximo.get(posicion).tamanyo / 2) * 700) / Sinc.tamanyoAjustes;
                x += ((sumaTamanyos + Sinc.LProximo.get(posicion).tamanyo / 2) * 700) / Sinc.tamanyoAjustes;
            }catch(Exception e){}
        }
        
        //Actualiza la posicion del puntero
        //Cambia la ubicación del puntero
        PantallaPrincipal.flechaProximo.setBounds(x-8, PantallaPrincipal.flechaProximo.getBounds().y, 16, 24);
    }
    
}
