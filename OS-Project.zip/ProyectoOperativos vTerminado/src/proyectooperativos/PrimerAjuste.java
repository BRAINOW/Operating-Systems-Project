package proyectooperativos;

import java.awt.Graphics;

/**
 *
 * @author brian y ana
 */
public class PrimerAjuste {
    public int ingresaProceso(Espacio newEspacio, Graphics panel){
        //Aqui se debe agregar el nuevo espacio en la lista de "Sinc" correspondiente
        //Retorna true en caso de que si lo pueda insertar, de lo contrario false
        int bandera=0;
        int i = 0;
        
        if(newEspacio.tamanyo>Sinc.limiteSuperior){
            return 2;
        }
        
        for (i = 0; i < Sinc.LPrimer.size(); i++) {//recorre la lista
            
            //Actualiza la lista para mostrar la posicion del scanner
            Sinc.dibujaLista(Sinc.LPrimer, panel, i);
            Sinc.posScannerPrimer = i; //Actualiza la ultima posicion del scanner
            Sinc.esperar(0.18);
            
            if(Sinc.LPrimer.get(i).tipo == 1 ){// si hay un espacio vacio
                if(Sinc.LPrimer.get(i).tamanyo>=newEspacio.tamanyo){//checa si el newEspacio cabe en ese i espacio
                    
                    if(Sinc.LPrimer.get(i).tamanyo!=newEspacio.tamanyo){//ES DIFERENTE EL ESPACIO
                        Sinc.LPrimer.get(i).tamanyo=Sinc.LPrimer.get(i).tamanyo-newEspacio.tamanyo;
                        //agrega espacio antes uno nuevo con el tamanio del nuevo
                        newEspacio.nBloqueInicial = Sinc.LPrimer.get(i).nBloqueInicial;
                        Sinc.LPrimer.add(i,newEspacio);
                    }else{// ES EL MISMO ESPACIO
                        //le ponemos todos los datos del nuevo a ese espacio vacio
                        Sinc.LPrimer.get(i).nombre = newEspacio.nombre;
                        Sinc.LPrimer.get(i).tipo = 2;//ahora es ocupado pero que se puede liberar
                        Sinc.LPrimer.get(i).color[0] = newEspacio.color[0];
                        Sinc.LPrimer.get(i).color[1] = newEspacio.color[1];
                        Sinc.LPrimer.get(i).color[2] = newEspacio.color[2];
                    }
                    bandera= 1;
                    break;
                }else{//es el ultimo y no cupo en algun espacio
                    bandera= 0;
                }
            }
        }
        
        if(!(i < Sinc.LPrimer.size())){
            Sinc.posScannerPrimer = -1; //En caso de entrar scanner = -1 = no muestra
        }
        return bandera;
    }
}
