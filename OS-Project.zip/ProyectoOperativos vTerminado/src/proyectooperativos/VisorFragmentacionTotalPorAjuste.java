/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectooperativos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import static proyectooperativos.Sinc.compruebaUltimaEntrada;

/**
 *
 * @author brian
 */
public class VisorFragmentacionTotalPorAjuste extends javax.swing.JFrame {

    int xMouse,yMouse;//UBICACION MOUSE
    DefaultCategoryDataset datosAjuste = new DefaultCategoryDataset();
    
    public VisorFragmentacionTotalPorAjuste() {
        initComponents();
        setIconImage(getIconImage());
        start();
        lblLeyenda.setText(Sinc.calculaLeyenda()); //Actualiza la leyenda de cual es el mejor ajuste
    }
    @Override
    public Image getIconImage(){
        Image retValue=Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("\\img\\ram.png"));
        return retValue;
    }
    boolean bandera = false;
    
    public void start(){
        
        String ajuste = "";
        float fragmentacionTotal=0;
        switch(listaAjustes.getSelectedIndex()){
            case 0: //Primer
                ajuste = "Primer ajuste";
                fragmentacionTotal = Sinc.fragTotalPrimerA;
                break;
            case 1: //Mejor
                ajuste = "Mejor ajuste";
                fragmentacionTotal = Sinc.fragTotalMejorA;
                break;
            case 2: //Proximo
                ajuste = "Proximo ajuste";
                fragmentacionTotal = Sinc.fragTotalProximoA;
                break;
        }
        
        lblTitulo.setText(ajuste.toUpperCase());
        lblAjuste.setText(ajuste+", Fragmentación total = "+fragmentacionTotal+"%");
        //Funcion para inicializar la pantalla
        fragmentacionAjuste(listaAjustes.getSelectedIndex());
        generaGraficoCircular();
        generaGraficoBarras();
        pack();
        actualizaTabla();
    }
    
    public void generaGraficoBarras(){
        String titulo = "";
        
        //Dependiendo de cual se el ajuste sera el titulo
        switch(listaAjustes.getSelectedIndex()){
            case 0: 
                titulo = "Fragmentación primer ajuste";
                break;
            case 1: 
                titulo = "Fragmentación mejor ajuste";
                break;
            case 2: 
                titulo = "Fragmentación proximo ajuste";
                
                break;
        }
        
        //Genera la estructura del grafico con los datos del Ajuste
        JFreeChart graficoAjuste = ChartFactory.createBarChart3D(
                titulo,
                "Fragmentación por bloque de memoria",
                "% de fragmentación total",
                datosAjuste,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );
        
        //Genera la imagen de panel del grafico
        ChartPanel chartPanelAjustes = new ChartPanel(graficoAjuste);
        chartPanelAjustes.setMouseWheelEnabled(true);
        chartPanelAjustes.setPreferredSize(new Dimension(770, 390));
        
        //Añade el grafico en pantalla
        panelBarrasAjuste.removeAll();
        panelBarrasAjuste.setLayout(new BorderLayout());
        panelBarrasAjuste.add(chartPanelAjustes,BorderLayout.NORTH);
    }
    
    public void fragmentacionAjuste( int numAjuste){
        float fragmentacion = 0;
        float suma = 0;
        datosAjuste = new DefaultCategoryDataset();
        ArrayList <Espacio> LAjuste = null;
        String tipo = "";
        
        //Actualiza los datos dependiendo de cual sea el ajuste
        switch(numAjuste){
            case 0: //Primer
                LAjuste = Sinc.LPrimer;
                tipo = "Primer ajuste";
                break;
            case 1: //Mejor
                LAjuste = Sinc.LMejor;
                tipo = "Mejor ajuste";
                break;
            case 2: //Proximo
                LAjuste = Sinc.LProximo;
                tipo = "Proximo ajuste";
                break;
        }
        
        //Recorre para comparar con la lista inicial
        for (int i = 0; i < Sinc.LInicial.size(); i++) {
            suma = 0;
            System.out.print("Bloque "+Sinc.LInicial.get(i).nBloqueInicial);
            
            //Calculamos la fragmentacion por bloques
            for (int j = 0; j < LAjuste.size(); j++) {
                //Si esta libre y es del mismo bloque
                if (LAjuste.get(j).tipo == 1 && LAjuste.get(j).nBloqueInicial == Sinc.LInicial.get(i).nBloqueInicial ) {
                    
                    //Suma contiene la suma del espacio libre de un mismo bloque
                    suma += LAjuste.get(j).tamanyo; //Acumulamos los tamaños del mismo bloque
                }
            }
            //En caso de que el espacio sea tipo 0 o la fragmentacion sea del 100% reportamos 0 de fragmentacion
            if(Sinc.LInicial.get(i).tipo == 0 || (100*suma)/Sinc.LInicial.get(i).tamanyo == 100){
                fragmentacion = 0;
            }else{
                //Realizamos regla de 3 para conocer el % de fragmentación
                fragmentacion = (100*suma)/Sinc.tamanyoAjustes;
            }
            
            //Agregamos los datos a la lista de datos de fragmentacion para las graficas
            datosAjuste.setValue(fragmentacion,tipo,"B"+(i+1));
            
            System.out.println(", %Frag. = "+ fragmentacion);
        }
    }
    
    public void generaGraficoCircular(){
        
        DefaultPieDataset datos = null;
        String titulo = "";
        
        //Actualiza los datos dependiendo de cual sea el ajuste
        switch(listaAjustes.getSelectedIndex()){
            case 0: 
                datos = Sinc.porcentajePrimerAjuste;
                titulo = "Ocupación primer ajuste";
                break;
            case 1: 
                datos = Sinc.porcentajeMejorAjuste;
                titulo = "Ocupación mejor ajuste";
                break;
            case 2: 
                datos = Sinc.porcentajeProximoAjuste;
                titulo = "Ocupación proximo ajuste";
                break;
        }
        
        
        //Genera la estructura del grafico de pastel
        JFreeChart graficoCircular = ChartFactory.createPieChart(
                titulo,
                datos,
                true, true, false
        );
        
        //Añade el grafico a pantalla
        ChartPanel panel = new ChartPanel(graficoCircular);
        panel.setMouseWheelEnabled(true);
        panel.setPreferredSize(new Dimension(430, 390));
        
        panelPastelAjuste.removeAll();
        panelPastelAjuste.setLayout(new BorderLayout());
        panelPastelAjuste.add(panel,BorderLayout.NORTH);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblLeyenda = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        panelAjuste = new javax.swing.JPanel();
        lblAjuste = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaHistorial = new javax.swing.JTable();
        panelBarrasAjuste = new javax.swing.JPanel();
        panelPastelAjuste = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnExit = new javax.swing.JButton();
        btnStart = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        listaAjustes = new javax.swing.JComboBox<>();
        fondoBlanco = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblLeyenda.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblLeyenda.setText("Ajuste mas eficiente: - Sistema Buddy:");
        getContentPane().add(lblLeyenda, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 690, 640, 30));

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(394, 29, -1, 0));

        panelAjuste.setBackground(new java.awt.Color(255, 255, 255));
        panelAjuste.setPreferredSize(new java.awt.Dimension(700, 60));

        javax.swing.GroupLayout panelAjusteLayout = new javax.swing.GroupLayout(panelAjuste);
        panelAjuste.setLayout(panelAjusteLayout);
        panelAjusteLayout.setHorizontalGroup(
            panelAjusteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1420, Short.MAX_VALUE)
        );
        panelAjusteLayout.setVerticalGroup(
            panelAjusteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 130, Short.MAX_VALUE)
        );

        getContentPane().add(panelAjuste, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 553, 1420, 130));

        lblAjuste.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblAjuste.setText("X Ajuste, Fragmentación total = 0.00%");
        getContentPane().add(lblAjuste, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 513, 651, 40));

        lblTitulo.setFont(new java.awt.Font("Segoe UI Variable", 0, 36)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(153, 193, 131));
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("X AJUSTE");
        getContentPane().add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(379, 35, 700, 65));

        tablaHistorial.setBackground(new java.awt.Color(194, 210, 178));
        tablaHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Proceso", "Tamaño"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaHistorial);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 106, 180, 386));

        panelBarrasAjuste.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout panelBarrasAjusteLayout = new javax.swing.GroupLayout(panelBarrasAjuste);
        panelBarrasAjuste.setLayout(panelBarrasAjusteLayout);
        panelBarrasAjusteLayout.setHorizontalGroup(
            panelBarrasAjusteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 770, Short.MAX_VALUE)
        );
        panelBarrasAjusteLayout.setVerticalGroup(
            panelBarrasAjusteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );

        getContentPane().add(panelBarrasAjuste, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 103, -1, -1));

        panelPastelAjuste.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout panelPastelAjusteLayout = new javax.swing.GroupLayout(panelPastelAjuste);
        panelPastelAjuste.setLayout(panelPastelAjusteLayout);
        panelPastelAjusteLayout.setHorizontalGroup(
            panelPastelAjusteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 430, Short.MAX_VALUE)
        );
        panelPastelAjusteLayout.setVerticalGroup(
            panelPastelAjusteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );

        getContentPane().add(panelPastelAjuste, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 103, -1, -1));

        jPanel1.setBackground(new java.awt.Color(153, 193, 131));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        btnExit.setBackground(new java.awt.Color(153, 193, 131));
        btnExit.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnExit.setForeground(new java.awt.Color(0, 0, 0));
        btnExit.setText("X");
        btnExit.setBorder(null);
        btnExit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnExit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnExitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnExitMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnExitMousePressed(evt);
            }
        });
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        btnStart.setBackground(new java.awt.Color(153, 193, 131));
        btnStart.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/play.png"))); // NOI18N
        btnStart.setToolTipText("START");
        btnStart.setBorder(null);
        btnStart.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        btnRegresar.setBackground(new java.awt.Color(153, 193, 131));
        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/deshacer.png"))); // NOI18N
        btnRegresar.setToolTipText("Regresar");
        btnRegresar.setBorder(null);
        btnRegresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65)
                .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1174, Short.MAX_VALUE)
                .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExit)
                    .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1500, -1));

        listaAjustes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Primer Ajuste", "Mejor Ajuste", "Proximo Ajuste" }));
        listaAjustes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listaAjustesActionPerformed(evt);
            }
        });
        getContentPane().add(listaAjustes, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        fondoBlanco.setBackground(new java.awt.Color(255, 255, 255));
        fondoBlanco.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoBlanco.png"))); // NOI18N
        fondoBlanco.setText("jLabel1");
        fondoBlanco.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                fondoBlancoMouseEntered(evt);
            }
        });
        getContentPane().add(fondoBlanco, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 1500, 720));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        start();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        start();
        
        //Funcion que llama para actualizar el dibujo de la memoria
        dibujaLista(listaAjustes.getSelectedIndex());
        if(!bandera){
            bandera = true;
            btnStartActionPerformed(evt);
        }
        
    }//GEN-LAST:event_btnStartActionPerformed

    public void dibujaLista (int numAjuste){
        ArrayList <Espacio> LAjuste = null;
        Graphics papel = panelAjuste.getGraphics();
        int x = 5;
        int y = 5;
        int width = 0;
        int pos = 0;
        
        //Actualiza los datos dependiendo de cual sea el ajuste
        switch(numAjuste){
            case 0: //Primer
                LAjuste = Sinc.LPrimer;
                pos = Sinc.posScannerPrimer;
                break;
            case 1: //Mejor
                LAjuste = Sinc.LMejor;
                pos = Sinc.posScannerMejor;
                break;
            case 2: //Proximo
                LAjuste = Sinc.LProximo;
                pos = Sinc.posScannerProximo;
                break;
        }
        //Se pinta el controrno de la memoria de verde si es que logro entrar y de rojo si es que no lo hizo
        switch(compruebaUltimaEntrada(LAjuste,papel)){
            case 0: //Bloqueado
                papel.setColor(Color.red);
                break;
            case 1: //Ingreso
                papel.setColor(Color.green);
                break;
            case 2: //Inanicion
                papel.setColor(Color.orange);
                break;
        }
        
        papel.fillRect(0, 0, 1420, 130);
        
        papel.setColor(Color.white);
        papel.fillRect(5, 5, 1410, 120);
        Font font = new Font("Arial",Font.BOLD,14);
        papel.setFont(font);
        
        
        for (int i = 0; i < LAjuste.size(); i++) {
            //En caso de ser el buddy se hace regla de 3 con 1024 kb
            font = new Font("Arial",Font.BOLD,14);
            papel.setFont(font);
            width = (int)(((float)1410*(float)LAjuste.get(i).tamanyo)/(float)Sinc.tamanyoAjustes); //Regla de 3
            
            //En caso de que el scanner se quedara en esta ubicacion se colocara un margen 
            if(pos!=-1 && i==pos ){
                papel.setColor(Color.MAGENTA);
                papel.fillRect(x-5, 0, width+10, 130);
            }
            
            if (LAjuste.get(i).tipo == 0) { //Ocupadisimo
                papel.setColor(Color.gray);
                if(pos!=-1 && i==pos+1){
                    papel.fillRect(x+5, y, width-5, 120);
                }else{
                    papel.fillRect(x, y, width, 120);
                }
                
                papel.setColor(Color.white);
                papel.drawString(Integer.toString(LAjuste.get(i).tamanyo), x-5+width/2, y+65);
            }
            
            if (LAjuste.get(i).tipo == 1) { //Libre
                papel.setColor(Color.LIGHT_GRAY);
                if(pos!=-1 && i==pos+1){
                    papel.drawRect(x+5, y, width-5, 120);
                }else{
                    papel.drawRect(x, y, width, 120);
                }
                
                papel.drawString(Integer.toString(LAjuste.get(i).tamanyo), x-5+width/2, y+65);
            }
            if (LAjuste.get(i).tipo == 2) { //Ocupado
                papel.setColor(new Color(LAjuste.get(i).color[0], LAjuste.get(i).color[1], LAjuste.get(i).color[2]));
                if(pos!=-1 && i==pos+1){
                    papel.fillRect(x+5, y, width-5, 120);
                }else{
                    papel.fillRect(x, y, width, 120);
                }
                font = new Font("Arial",Font.BOLD,12);
                papel.setFont(font);
            
                papel.setColor(Color.black);
                papel.drawString("P:"+LAjuste.get(i).nombre, x-5+width/2, y+55);
                papel.drawString("T:"+Integer.toString(LAjuste.get(i).tamanyo), x-5+width/2-5, y+75);
                //PantallaPrincipal.flechaPrimer1.setBounds(x, 205, 16, 15);
            }
            x+=width;
        }
    }
    
    public void actualizaTabla(){
        
        DefaultTableModel dtm;
        //Crea un objeto para la fila de la tabla
        Object[] fila = new Object[2];
        
        //Obtiene el modelo de la tabla
        dtm = (DefaultTableModel) tablaHistorial.getModel();
        dtm.getDataVector().removeAllElements(); //Limpia la tabla
        dtm.fireTableDataChanged();
        
        //Recorre los registros de la tabla
        for (int i = 0; i < Sinc.LTabla.size(); i++) {
            //Llena el objeto fila con lo corespondiente al registro
            fila[0] = Sinc.LTabla.get(i).nombre;
            fila[1] = Sinc.LTabla.get(i).tamanyo;
            
            //Agregara solamente las filas de los procesos qe esten el en ajuste seleccionado
            if(compLiberarProceso(fila[0].toString())){ //Flujo normal
                switch(listaAjustes.getSelectedIndex()){
                    case 0: 
                        if(Sinc.LTabla.get(i).resultadoPimerA==1){
                            dtm.addRow(fila);
                        }
                        break;
                    case 1: 
                        if(Sinc.LTabla.get(i).resultadoMejorA==1){
                            dtm.addRow(fila);
                        }
                        break;
                    case 2: 
                        if(Sinc.LTabla.get(i).resultadoProximoA==1){
                            dtm.addRow(fila);
                        }
                        break;
                }
            }
        }
    }
    
    public boolean compLiberarProceso(String proceso){
        //retorna true si el proceso ya salio
        for (int i = 0; i < Sinc.LTabla.size(); i++) {
            if("Salida".equals(Sinc.LTabla.get(i).tipoES) && Sinc.LTabla.get(i).nombre.equals(proceso)){
                return false;
            }
        }
        return true;
    }
    
    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        //Regresa a pantalla principal
        Sinc.pantallaPrincipal.setVisible(true);
        Sinc.pantallaPrincipal.setSize(1300, 650);
        Sinc.pantallaPrincipal.setResizable(false);
        Sinc.pantallaPrincipal.setLocationRelativeTo(null);//en medio
        this.dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
        
        btnStartActionPerformed(null);
            
    }//GEN-LAST:event_formMouseEntered

    private void btnExitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMouseEntered
        //listo
        btnExit.setBackground(Color.red);
    }//GEN-LAST:event_btnExitMouseEntered

    private void btnExitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMouseExited
        //listo
        btnExit.setBackground(new Color(153,193,131));
    }//GEN-LAST:event_btnExitMouseExited

    private void btnExitMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnExitMousePressed
        //listo
        System.exit(0);
    }//GEN-LAST:event_btnExitMousePressed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        //NO SE OCUPA
    }//GEN-LAST:event_btnExitActionPerformed

    private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
        int x = evt.getXOnScreen();
        int y =evt.getYOnScreen();
        this.setLocation(x-xMouse,y-yMouse);
    }//GEN-LAST:event_jPanel1MouseDragged

    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_jPanel1MousePressed

    private void listaAjustesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listaAjustesActionPerformed
        start();
        dibujaLista(listaAjustes.getSelectedIndex());
    }//GEN-LAST:event_listaAjustesActionPerformed

    private void fondoBlancoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fondoBlancoMouseEntered
        btnStartActionPerformed(null);
    }//GEN-LAST:event_fondoBlancoMouseEntered


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnStart;
    private javax.swing.JLabel fondoBlanco;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAjuste;
    private javax.swing.JLabel lblLeyenda;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JComboBox<String> listaAjustes;
    private javax.swing.JPanel panelAjuste;
    private javax.swing.JPanel panelBarrasAjuste;
    private javax.swing.JPanel panelPastelAjuste;
    private javax.swing.JTable tablaHistorial;
    // End of variables declaration//GEN-END:variables
}
