package proyectooperativos;

import java.awt.Graphics;

/**
 *
 * @author brian
 */
public class SistemaBuddy {
    public int ingresaProceso(Espacio nEspacio, Graphics panelBuddy){
        //Aqui se debe agregar el nuevo espacio en la lista de "Sinc" correspondiente
        //Retorna true en caso de que si lo pueda insertar, de lo contrario false
        
        if(nEspacio.tamanyo>1024){
            return 2;
        }
        
        for (int i = 0; i < Sinc.LBuddy.size(); i++) {
            if(Sinc.LBuddy.get(i).tipo == 1 ){
                //o ocupado, 1 libre, 2 ocupado pero se puede liberar
                if(Sinc.LBuddy.get(i).tamanyo >= nEspacio.tamanyo  ){
                    
                    //Actualiza lentamente la lista mientras se divide la memoria
                    Sinc.dibujaLista(Sinc.LBuddy, panelBuddy,Sinc.posScannerPrimer);
                    Sinc.esperar(0.30);
                    
                    //En caso de que el espacio no cumpla con los requisitos del sistema buddy se divide 
                        /*  EJEMPLO
                        256 < A=64 <= 512
                        128 < A=64 <= 256
                        64 < A=64 <= 128
                        32 < A=64 <= 64
                        */
                    if(Sinc.LBuddy.get(i).tamanyo/2 < nEspacio.tamanyo && nEspacio.tamanyo<= Sinc.LBuddy.get(i).tamanyo ){
                        
                        //Si entra se calcula el desperdicio de ese bloque de memoria
                        Sinc.LBuddy.get(i).desperdicio = Sinc.LBuddy.get(i).tamanyo - nEspacio.tamanyo;
                        
                        //Se copian los valores del nuevo espacio
                        Sinc.LBuddy.get(i).nombre = nEspacio.nombre;
                        Sinc.LBuddy.get(i).tipo = 2;
                        Sinc.LBuddy.get(i).color[0] = nEspacio.color[0];
                        Sinc.LBuddy.get(i).color[1] = nEspacio.color[1];
                        Sinc.LBuddy.get(i).color[2] = nEspacio.color[2];
                        return 1; //Si entro 
                    }else{
                        //Se divide el tamaño de memoria de ese bloque
                        Sinc.LBuddy.get(i).tamanyo /= 2;
                        
                        //Genera un nevo espacio con las caracteristicas del espacio que se dividio, de esta forma son "hermanos"
                        Espacio e = new Espacio(
                                Sinc.LBuddy.get(i).tamanyo, 
                                1,
                                Sinc.LBuddy.get(i).nBloqueInicial
                        );
                        
                        //Añadimos el hermano a la lista de hermanos del espacio de memoria
                        Sinc.LBuddy.get(i).LHermanos.add(0,Sinc.cuentaHermanos);
                        e.LHermanos.add(0,Sinc.cuentaHermanos);
                        
                        //Se aumenta el contador de hermanos global
                        Sinc.cuentaHermanos++;
                        
                        //Se añade el espacio
                        Sinc.LBuddy.add(i,e);
                        
                        //Utilizamos recursividad hasta que entre el proceso
                        return ingresaProceso(nEspacio,panelBuddy);
                    }
                }
            }
        }
        
        return 0; 
    }
}
