package proyectooperativos;

import java.util.ArrayList;

/**
 * @author brian
 * 
 * Este es el archivo del objeto que compóndra la cadena de las listas de los Ajustes
 * 
 * dentro de este se definen las caracteristicas necesarias a tener para todos los Ajustes
 */
public class Espacio {
    
    String nombre; //Seran letras, si pasa de la Z sera ahora AA, AB, ...
    int tamanyo; //Tamaño del espacio
    int tipo; //0.-Ocupado no liberable, 1.- Espacio libre, 2.- Espacio ocupado liberable
    int color[] = new int[3];
    int desperdicio; //Para el buddy
    int nBloqueInicial; //Define cual es su espacio para considerar la fragmentación
    ArrayList <Integer> LHermanos = new ArrayList<>();
    
    public Espacio(){
        
    }
    
    //PAra cuando se inicializa en cualquier ajsute o buddy
    public Espacio(String nombre, int tamanyo, int tipo){
        this.nombre = nombre;
        this.tamanyo = tamanyo;
        this.tipo = tipo;
    }
    
    //Para inicializar los no liberables
    public Espacio(int tamanyo, int tipo){
        this.tamanyo = tamanyo;
        this.tipo = tipo;
    }
    
    public Espacio(int tamanyo, int tipo, int nBloqueInicial){
        this.tamanyo = tamanyo;
        this.tipo = tipo;
        this.nBloqueInicial = nBloqueInicial;
    }
    
    public Espacio(int tamanyo, int tipo, int nBloqueInicial, int nivel){
        this.tamanyo = tamanyo;
        this.tipo = tipo;
        this.nBloqueInicial = nBloqueInicial;
    }
    
    public Espacio(int tipo, String nombre, int tamanyo, int color0, int color1, int color2){
        this.tipo = 2;
        this.nombre = nombre;
        this.tamanyo = tamanyo;
        this.color[0] = color0;
        this.color[1] = color1;
        this.color[2] = color2;
    }
    
}
