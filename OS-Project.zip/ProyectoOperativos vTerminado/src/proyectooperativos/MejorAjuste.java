/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectooperativos;

import java.awt.Graphics;

/**
 *
 * @author brian
 */
public class MejorAjuste {
    int indiceIdeal=-1;
    public int ingresaProceso(Espacio newEspacio, Graphics panel) {
        int rf = 0;
        int residuo = Integer.MAX_VALUE;
        indiceIdeal=-1;
        
        if(newEspacio.tamanyo>Sinc.limiteSuperior){
            return 2;
        }
        
        for (int i = 0; i < Sinc.LMejor.size(); i++) {
            //Actualiza la lista para mostrar la posicion del scanner
            Sinc.dibujaLista(Sinc.LMejor, panel, i);
            Sinc.posScannerMejor = i; //Actualiza la ultima posicion del scanner
            Sinc.esperar(0.18);
            
            // Recorre la lista de asignaciones
            if (Sinc.LMejor.get(i).tipo == 1) {
                if (Sinc.LMejor.get(i).tamanyo >= newEspacio.tamanyo) {
                    // Valida que el espacio sea igual o mayor al tamaño solicitado
                    if (Sinc.LMejor.get(i).tamanyo == newEspacio.tamanyo) {
                        // El nuevo espacio cabe exactamente en el espacio existente
                        newEspacio.nBloqueInicial = Sinc.LPrimer.get(i).nBloqueInicial;
                        Sinc.LMejor.remove(i);
                        Sinc.LMejor.add(i,newEspacio);
                        rf = 1; // Devuelve true para indicar que se asignó correctamente
                        indiceIdeal = i;
                        Sinc.posScannerMejor = indiceIdeal; //Actualiza la ultima posicion del scanner
                        return rf;
                    } else {
                        if(Sinc.LMejor.get(i).tamanyo-newEspacio.tamanyo < residuo){
                            indiceIdeal = i;
                            residuo = Sinc.LMejor.get(i).tamanyo-newEspacio.tamanyo;
                        }
                    }
                }
            }
        }
        
        //En caso de que no entre
        if(indiceIdeal == -1){
            Sinc.posScannerMejor = -1; //Actualiza la ultima posicion del scanner
            return 0;
        }
        
        // Actualiza el espacio asignado
        Sinc.LMejor.get(indiceIdeal).tamanyo -= newEspacio.tamanyo;

        // Agrega un nuevo espacio ocupado con el tamaño del nuevo
        newEspacio.nBloqueInicial = Sinc.LMejor.get(indiceIdeal).nBloqueInicial;
        Sinc.LMejor.add(indiceIdeal, newEspacio);
        rf = 1; // Devuelve true para indicar que se asignó correctamente
        Sinc.posScannerMejor = indiceIdeal; //Actualiza la ultima posicion del scanner
        return rf;
    }
}
