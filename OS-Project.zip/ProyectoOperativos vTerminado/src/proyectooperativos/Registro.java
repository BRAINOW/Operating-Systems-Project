
package proyectooperativos;

/**
 *
 * @author brian
 */
public class Registro {
    //Contiene nombre y tamaño
    String nombre;
    int tamanyo; 
    String tipoES; //Guarda si es entrada o salida
    
    //Los resultados almacenan si fue efectivo el almacenado
    int resultadoPimerA;
    int resultadoMejorA;
    int resultadoProximoA;
    int resultadoBuddy;
}
